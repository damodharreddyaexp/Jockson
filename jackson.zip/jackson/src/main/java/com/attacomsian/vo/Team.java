package com.attacomsian.vo;

class Team {
	String id;
	String city;
	String name;
	String abbreviation;
}