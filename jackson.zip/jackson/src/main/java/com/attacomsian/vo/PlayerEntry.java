package com.attacomsian.vo;

class PlayerEntry {
	Player player;
	Team team;
}
