package com.attacomsian.vo;

public class TableRowHeader {
	private String rowHeader;

	/**
	 * @return the rowHeader
	 */
	public String getRowHeader() {
		return rowHeader;
	}

	/**
	 * @param rowHeader the rowHeader to set
	 */
	public void setRowHeader(String rowHeader) {
		this.rowHeader = rowHeader;
	}

	@Override
	public String toString() {
		return "TableRowHeader [rowHeader=" + rowHeader + "]";
	}

}
