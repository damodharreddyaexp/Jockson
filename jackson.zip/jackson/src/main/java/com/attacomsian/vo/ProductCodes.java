package com.attacomsian.vo;

public class ProductCodes {

    private String productName;

    private CardMemberRequestModel cardMemberVo;

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	
	public ProductCodes(String productName, CardMemberRequestModel cardMemberVo) {
		super();
		this.productName = productName;
		this.cardMemberVo = cardMemberVo;
	}



	public ProductCodes(String productName) {
		super();
		this.productName = productName;
	}


	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the cardMemberVo
	 */
	public CardMemberRequestModel getCardMemberVo() {
		return cardMemberVo;
	}

	/**
	 * @param cardMemberVo the cardMemberVo to set
	 */
	public void setCardMemberVo(CardMemberRequestModel cardMemberVo) {
		this.cardMemberVo = cardMemberVo;
	}

}
