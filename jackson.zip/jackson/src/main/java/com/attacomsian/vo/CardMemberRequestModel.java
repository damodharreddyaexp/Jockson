package com.attacomsian.vo;

public class CardMemberRequestModel {

	private String airLines;
	private String lodging;
	private int zipcode;
	private String country;
	private String formId;
	private String formName;

	/**
	 * @return the airLines
	 */
	public String getAirLines() {
		return airLines;
	}

	/**
	 * @param airLines the airLines to set
	 */
	public void setAirLines(String airLines) {
		this.airLines = airLines;
	}

	/**
	 * @return the lodging
	 */
	public String getLodging() {
		return lodging;
	}

	/**
	 * @param lodging the lodging to set
	 */
	public void setLodging(String lodging) {
		this.lodging = lodging;
	}

	/**
	 * @return the zipcode
	 */
	public int getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the formId
	 */
	public String getFormId() {
		return formId;
	}

	/**
	 * @param formId the formId to set
	 */
	public void setFormId(String formId) {
		this.formId = formId;
	}

	/**
	 * @return the formName
	 */
	public String getFormName() {
		return formName;
	}

	/**
	 * @param formName the formName to set
	 */
	public void setFormName(String formName) {
		this.formName = formName;
	}

}
