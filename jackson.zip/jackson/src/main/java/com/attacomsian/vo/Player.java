package com.attacomsian.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

class Player {

    @JsonProperty("ID")
    String id;
    @JsonProperty("LastName")
    String lastName;
    @JsonProperty("FirstName")
    String firstName;
}

