package com.attacomsian.vo;

import java.util.List;

public class Roasterplayers {
	String lastUpdatedOn;
	List<PlayerEntry> playerentry;
}
