package com.attacomsian.response;

import java.util.List;
import java.util.Map;

import com.attacomsian.vo.ProductCodes;

public class CardMemberResponse {

	Map<String, List<ProductCodes>> cardMember;
	/*
	 * private List<String> row; private Map<String, TableRowHeader> channels;
	 */

	/**
	 * @return the cardMember
	 */
	public Map<String, List<ProductCodes>> getCardMember() {
		return cardMember;
	}

	/**
	 * @param cardMember the cardMember to set
	 */
	public void setCardMember(Map<String, List<ProductCodes>> cardMember) {
		this.cardMember = cardMember;
	}

}
