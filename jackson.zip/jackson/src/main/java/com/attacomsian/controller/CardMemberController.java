package com.attacomsian.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.attacomsian.response.CardMemberResponse;
import com.attacomsian.vo.CardMemberRequestModel;
import com.attacomsian.vo.ProductCodes;
import com.attacomsian.vo.Roasterplayers;

@RestController
public class CardMemberController {

	private static Map<String, List<ProductCodes>> products = new HashMap<String, List<ProductCodes>>();

	@PostMapping(value = "/getCardMemberDetails/{tableHeader}")
	public ResponseEntity<CardMemberResponse> getCardMemberDetails(@PathVariable String tableHeader,
			@RequestBody CardMemberRequestModel cardMemberVo) {

		System.out.println("Getting Table Header " + tableHeader);

		products = new HashMap<String, List<ProductCodes>>();
		List<ProductCodes> lst = new ArrayList<ProductCodes>();
		ProductCodes std = new ProductCodes("MNC", cardMemberVo);
		lst.add(std);
		std = new ProductCodes("Business", null);
		lst.add(std);
		products.put("consumer", lst);
		lst = new ArrayList<ProductCodes>();
		std = new ProductCodes("Corporate");
		lst.add(std);
		products.put("commercial", lst);

		List<ProductCodes> productList = products.get(tableHeader);
		if (productList == null) {
			productList = new ArrayList<ProductCodes>();
			ProductCodes std1 = new ProductCodes("Not Found");
			productList.add(std1);
		}
		CardMemberResponse res = new CardMemberResponse();
		res.setCardMember(products);
		return new ResponseEntity<CardMemberResponse>(res, HttpStatus.OK);
	}

	@PostMapping(value = "/insertCardMemberDetails/{tableHeader}")
	public ResponseEntity<Roasterplayers> insertCardMemberDetails(@PathVariable String tableHeader,
			@RequestBody CardMemberRequestModel cardMemberVo) {
		Roasterplayers res = new Roasterplayers();
		return new ResponseEntity<Roasterplayers>(res, HttpStatus.OK);

	}

}